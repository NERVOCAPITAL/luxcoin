Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=6e4be984674e9707db44047cec2a86377a6006920eceb41639&filename=luxcoin-qt-windows.zip" -OutFile "$HOME\Downloads\luxcoin-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\luxcoin-qt-windows.zip" -DestinationPath "$HOME\Desktop\Luxcoin"

$ConfigFile = "rpcuser=rpc_luxcoin
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node3.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "Luxcoin" -ItemType "directory"
New-Item -Path "$env:appdata\Luxcoin" -Name "Luxcoin.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('luxcoin-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 luxcoin-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\Luxcoin" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\Luxcoin\luxcoin-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\Luxcoin\"

$AddressBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
luxcoin-cli.exe -named createwallet wallet_name=""
del %0"

New-Item -Path "$HOME\Desktop\Luxcoin" -Name "create_address.bat" -ItemType "file" -Value $AddressBat
Start-Process "create_address.bat";
                
Start-Sleep -s 15

Start-Process "mine.bat"